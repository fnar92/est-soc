<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
#logo{
    text-align:center;
    }
#contenido{
    /*background: linear-gradient(to bottom, #FFF 9%, #C7C8CA 100%) repeat scroll 0% 0% transparent;*/
    /*text-align:center;*/
}

#foot{
    text-align:center;
}
        </style>
    </head>
    <body>
    
    <div id="contenido">
    	content
    </div>
        
    <div id="logo">
        <p><img src="http://www.hrwise.com.mx/assets/page/images/logo_pn.png" width="100" height="35"></p>
    </div>
    
    </body>
</html>
